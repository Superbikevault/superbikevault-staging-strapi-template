/**
 * ad-block router
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreRouter('api::ad-block.ad-block');
