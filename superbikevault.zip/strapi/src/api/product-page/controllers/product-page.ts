/**
 * product-page controller
 */

import { factories } from '@strapi/strapi'

export default factories.createCoreController('api::product-page.product-page');
